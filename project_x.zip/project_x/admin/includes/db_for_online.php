<?php

$host = "localhost";
$user = "clfuckstick";
$password = "]HxPDjcMsMM!";
$dbase = "cl_gym_demo";

$connection = mysqli_connect($host, $user, $password, $dbase);

?>
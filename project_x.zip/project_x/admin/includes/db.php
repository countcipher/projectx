<?php

//FOR LOCAL HOSTING
$host = "localhost";
$user = "evolution_admin201996";
$password = "STcmS5L9rFhIu6Wc";
$dbase = "project_x";

/*$host = "localhost";
$user = "joker5454";
$password = "aNC13ntCh@r13t";
$dbase = "projectx_cl";*/

$connection = mysqli_connect($host, $user, $password, $dbase);

/*if($connection){
    echo "yes";
}else{
    echo "no";
}*/

?>
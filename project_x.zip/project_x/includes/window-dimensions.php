<!--FOR GETTING WINDOW DIMENSIONS
=================================================-->

    <div id="dimensions">
       <p id="width">Width: </p>
       <p id="height">Height: </p>
    </div>